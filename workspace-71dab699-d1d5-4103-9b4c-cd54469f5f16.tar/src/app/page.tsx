"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform, useInView } from "framer-motion";
import Image from "next/image";
import {
  Camera,
  Search,
  ShoppingBag,
  Star,
  Sparkles,
  Heart,
  Share2,
  Zap,
  Download,
  ChevronRight,
  ArrowRight,
  Check,
  X,
  Shield,
  Users,
  TrendingUp,
  Eye,
  Smartphone,
  Scan,
  BadgeDollarSign,
  Palette,
  Link2,
  BookmarkPlus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

/* ─── ANIMATION VARIANTS ─── */
const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, delay: i * 0.1, ease: [0.25, 0.46, 0.45, 0.94] },
  }),
};

const fadeIn = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.8 } },
};

const scaleIn = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: (i: number = 0) => ({
    opacity: 1,
    scale: 1,
    transition: { duration: 0.6, delay: i * 0.12 },
  }),
};

const stagger = {
  visible: { transition: { staggerChildren: 0.1 } },
};

/* ─── SECTION WRAPPER (scroll-triggered) ─── */
function AnimatedSection({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });
  return (
    <motion.section
      ref={ref}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      variants={fadeUp}
      custom={delay}
      className={className}
    >
      {children}
    </motion.section>
  );
}

/* ─── STAR RATING ─── */
function StarRating({ count = 5 }: { count?: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`w-4 h-4 ${
            i < count
              ? "fill-amber-400 text-amber-400"
              : "fill-gray-200 text-gray-200"
          }`}
        />
      ))}
    </div>
  );
}

/* ─── DOWNLOAD BUTTON ─── */
function DownloadButton({
  size = "default",
  className = "",
}: {
  size?: "default" | "lg";
  className?: string;
}) {
  const isLarge = size === "lg";
  return (
    <motion.div
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.97 }}
      className={className}
    >
      <button
        className={`
          group relative overflow-hidden
          ${isLarge ? "px-10 py-5 text-lg" : "px-7 py-3.5 text-base"}
          rounded-2xl font-semibold
          text-white shadow-lg
          transition-shadow duration-300
          hover:shadow-2xl hover:shadow-coral/25
          focus:outline-none focus:ring-4 focus:ring-coral/30
          cursor-pointer
        `}
        style={{
          background: "linear-gradient(135deg, #E8505B 0%, #FF8A6B 50%, #F59E0B 100%)",
        }}
      >
        <span className="relative z-10 flex items-center justify-center gap-2.5">
          <Download className={isLarge ? "w-5 h-5" : "w-4 h-4"} />
          Download Free
          <ArrowRight
            className={`transition-transform duration-300 group-hover:translate-x-1 ${
              isLarge ? "w-5 h-5" : "w-4 h-4"
            }`}
          />
        </span>
        <span className="absolute inset-0 animate-shimmer opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </button>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════
   HERO SECTION
   ═══════════════════════════════════════════ */
function HeroSection() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const heroY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <motion.section
      ref={ref}
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{ y: heroY, opacity: heroOpacity }}
    >
      {/* Background image with overlay */}
      <div className="absolute inset-0">
        <Image
          src="/images/hero-street.png"
          alt="Stylish people in urban setting"
          fill
          className="object-cover object-center"
          priority
          quality={90}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/80 to-white/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-white/60" />
      </div>

      {/* Floating decorative elements */}
      <div className="absolute top-20 right-[15%] w-72 h-72 rounded-full bg-coral/5 blur-3xl" />
      <div className="absolute bottom-20 left-[10%] w-96 h-96 rounded-full bg-amber/5 blur-3xl" />

      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 pt-28 pb-20 lg:pt-0 lg:pb-0">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          {/* Left: Copy */}
          <div className="max-w-xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <Badge
                variant="secondary"
                className="mb-6 px-4 py-1.5 text-sm font-medium rounded-full"
                style={{
                  background: "rgba(232,80,91,0.1)",
                  color: "var(--coral)",
                  border: "1px solid rgba(232,80,91,0.2)",
                }}
              >
                <Sparkles className="w-3.5 h-3.5 mr-1.5" />
                AI-Powered Fashion Intelligence
              </Badge>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.05] tracking-tight mb-6"
              style={{ fontFamily: "var(--font-playfair), Georgia, serif" }}
            >
              See an outfit.{" "}
              <span className="text-gradient">Own it</span> in 10
              seconds.
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
              className="text-lg sm:text-xl text-text-secondary leading-relaxed mb-8 max-w-md"
            >
              Snap any outfit anywhere. Our AI identifies every single piece
              &mdash; then finds where to buy it, at the best price.
              <span className="font-semibold text-charcoal">
                {" "}
                No more &ldquo;where did they get that?&rdquo;
              </span>
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="flex flex-col sm:flex-row gap-4 mb-10"
            >
              <DownloadButton size="lg" />
              <div className="flex items-center gap-4 text-sm text-text-secondary self-center">
                <div className="flex -space-x-2">
                  {[
                    "bg-coral",
                    "bg-amber",
                    "bg-emerald-400",
                    "bg-violet-400",
                  ].map((color, i) => (
                    <div
                      key={i}
                      className={`w-8 h-8 rounded-full ${color} border-2 border-white flex items-center justify-center text-white text-xs font-bold`}
                    >
                      {["S", "J", "P", "M"][i]}
                    </div>
                  ))}
                </div>
                <div>
                  <div className="font-semibold text-charcoal">50K+</div>
                  <div className="text-xs text-text-muted">style spotters</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.7 }}
              className="flex items-center gap-6 text-sm text-text-muted"
            >
              <div className="flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-emerald-500" />
                <span>Free to use</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-coral" />
                <span>iOS & Android</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span>4.9 on App Store</span>
              </div>
            </motion.div>
          </div>

          {/* Right: Phone Mockup */}
          <motion.div
            initial={{ opacity: 0, x: 60, rotateY: -10 }}
            animate={{ opacity: 1, x: 0, rotateY: 0 }}
            transition={{ duration: 1, delay: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="relative flex justify-center lg:justify-end"
          >
            <div className="relative">
              {/* Phone frame */}
              <div className="phone-frame relative w-[280px] sm:w-[300px] h-[560px] sm:h-[600px] bg-charcoal rounded-[2.5rem] overflow-hidden border-[6px] border-gray-800">
                {/* Notch */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-7 bg-gray-800 rounded-b-2xl z-20" />

                {/* Screen content - mockup image */}
                <div className="relative w-full h-full overflow-hidden">
                  <Image
                    src="/images/app-mockup.png"
                    alt="SpotStyle app interface"
                    fill
                    className="object-cover"
                    priority
                  />

                  {/* Scanning overlay animation */}
                  <motion.div
                    className="absolute left-4 right-4 h-0.5 z-10"
                    style={{
                      background:
                        "linear-gradient(90deg, transparent, #E8505B, transparent)",
                    }}
                    initial={{ top: "15%" }}
                    animate={{ top: "85%" }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      repeatType: "reverse",
                      ease: "easeInOut",
                    }}
                  />

                  {/* Scan corners */}
                  <div className="absolute top-16 left-4 w-8 h-8 border-t-2 border-l-2 border-coral rounded-tl-lg" />
                  <div className="absolute top-16 right-4 w-8 h-8 border-t-2 border-r-2 border-coral rounded-tr-lg" />
                  <div className="absolute bottom-24 left-4 w-8 h-8 border-b-2 border-l-2 border-coral rounded-bl-lg" />
                  <div className="absolute bottom-24 right-4 w-8 h-8 border-b-2 border-r-2 border-coral rounded-br-lg" />

                  {/* Bottom card overlay */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/60 to-transparent pt-16 pb-6 px-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-white/80 text-xs font-medium">
                        4 items identified
                      </span>
                    </div>
                    <div className="space-y-2">
                      {[
                        { name: "Oversized Trench Coat", price: "$189", match: "98%" },
                        { name: "Slim Fit Denim", price: "$79", match: "95%" },
                      ].map((item, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 1 + i * 0.3, duration: 0.5 }}
                          className="flex items-center justify-between bg-white/10 backdrop-blur-sm rounded-lg px-3 py-2"
                        >
                          <div>
                            <div className="text-white text-xs font-medium">
                              {item.name}
                            </div>
                            <div className="text-white/50 text-[10px]">
                              {item.match} match
                            </div>
                          </div>
                          <div className="text-coral font-bold text-sm">
                            {item.price}
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating badges around phone */}
              <motion.div
                className="absolute -left-16 top-28 glass rounded-xl px-3 py-2 shadow-lg"
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-coral/10 flex items-center justify-center">
                    <Camera className="w-4 h-4 text-coral" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-charcoal">
                      Snapped!
                    </div>
                    <div className="text-[10px] text-text-muted">
                      Processing...
                    </div>
                  </div>
                </div>
              </motion.div>

              <motion.div
                className="absolute -right-12 top-48 glass rounded-xl px-3 py-2 shadow-lg"
                animate={{ y: [0, 8, 0] }}
                transition={{
                  duration: 5,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 1,
                }}
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center">
                    <Check className="w-4 h-4 text-emerald-500" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-charcoal">
                      Found it!
                    </div>
                    <div className="text-[10px] text-emerald-600">
                      Best: $142
                    </div>
                  </div>
                </div>
              </motion.div>

              <motion.div
                className="absolute -left-8 bottom-32 glass rounded-xl px-3 py-2 shadow-lg"
                animate={{ y: [0, -6, 0] }}
                transition={{
                  duration: 3.5,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 0.5,
                }}
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-amber-light flex items-center justify-center">
                    <BadgeDollarSign className="w-4 h-4 text-amber-600" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-charcoal">
                      Save 62%
                    </div>
                    <div className="text-[10px] text-text-muted">
                      Budget match
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 rounded-full border-2 border-text-muted/30 flex justify-center pt-2">
          <motion.div
            className="w-1 h-2 rounded-full bg-text-muted/50"
            animate={{ y: [0, 12, 0], opacity: [1, 0.3, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </div>
      </motion.div>
    </motion.section>
  );
}

/* ═══════════════════════════════════════════
   TRUST BAR / SOCIAL PROOF MARQUEE
   ═══════════════════════════════════════════ */
function TrustBar() {
  const items = [
    "Featured on TechCrunch",
    "\"The future of fashion discovery\"",
    "50,000+ downloads",
    "4.9 ★ on App Store",
    "\"Life-changing for fashion lovers\"",
    "As seen on Product Hunt",
    "#1 Fashion App of the Week",
    "\"I spotted a coat on the subway. Owned it in 10 seconds.\"",
  ];

  return (
    <AnimatedSection className="py-6 border-y border-border overflow-hidden bg-white">
      <div className="relative">
        <div className="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-white to-transparent z-10" />
        <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-white to-transparent z-10" />
        <div className="flex animate-marquee whitespace-nowrap">
          {[...items, ...items].map((item, i) => (
            <div
              key={i}
              className="flex items-center gap-3 mx-8 shrink-0"
            >
              <span className="text-sm text-text-muted font-medium">
                {item}
              </span>
              <div className="w-1 h-1 rounded-full bg-coral/40" />
            </div>
          ))}
        </div>
      </div>
    </AnimatedSection>
  );
}

/* ═══════════════════════════════════════════
   PROBLEM SECTION — "THE OUTFIT YOU'LL NEVER FIND"
   ═══════════════════════════════════════════ */
function ProblemSection() {
  return (
    <AnimatedSection className="py-20 sm:py-28 bg-warm-gray bg-mesh" delay={0.1}>
      <div className="max-w-4xl mx-auto px-6 sm:px-8 text-center">
        <motion.p
          variants={fadeUp}
          className="text-coral font-semibold text-sm uppercase tracking-widest mb-4"
        >
          Sound familiar?
        </motion.p>

        <motion.h2
          variants={fadeUp}
          custom={1}
          className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-12 leading-tight"
          style={{ fontFamily: "var(--font-playfair), Georgia, serif" }}
        >
          How many times have you seen someone on the street and thought&hellip;
        </motion.h2>

        <motion.div
          variants={stagger}
          className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto mb-14"
        >
          {[
            {
              icon: <Eye className="w-6 h-6" />,
              thought: "I NEED that jacket.",
              color: "bg-coral/10 text-coral",
            },
            {
              icon: <Search className="w-6 h-6" />,
              thought: "Where do I even start looking?",
              color: "bg-amber/10 text-amber",
            },
            {
              icon: <X className="w-6 h-6" />,
              thought: "*gives up after 20 minutes*",
              color: "bg-gray-100 text-gray-400",
            },
          ].map((item, i) => (
            <motion.div
              key={i}
              variants={scaleIn}
              custom={i}
              className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <div
                className={`w-12 h-12 rounded-xl ${item.color} flex items-center justify-center mb-4 mx-auto`}
              >
                {item.icon}
              </div>
              <p className="text-charcoal font-semibold text-base">
                &ldquo;{item.thought}&rdquo;
              </p>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          variants={fadeUp}
          custom={4}
          className="inline-flex items-center gap-3 bg-white rounded-full px-6 py-3 shadow-sm border border-border"
        >
          <span className="text-text-muted text-sm">Spoiler:</span>
          <span className="font-semibold text-charcoal">
            You won&apos;t find it on Google.
          </span>
          <ArrowRight className="w-4 h-4 text-coral" />
        </motion.div>
      </div>
    </AnimatedSection>
  );
}

/* ═══════════════════════════════════════════
   HOW IT WORKS — 3 STEPS
   ═══════════════════════════════════════════ */
function HowItWorks() {
  const steps = [
    {
      num: "01",
      icon: <Camera className="w-7 h-7" />,
      title: "Snap",
      subtitle: "Point & Shoot",
      description:
        "Point your camera at any outfit. Walking down the street, scrolling TikTok, watching Netflix, screenshotting Instagram — anywhere. If you can see it, SpotStyle can find it.",
      color: "from-coral to-peach",
      bgLight: "bg-coral/5",
      iconBg: "bg-coral/10 text-coral",
    },
    {
      num: "02",
      icon: <Scan className="w-7 h-7" />,
      title: "Spot",
      subtitle: "AI Does Its Thing",
      description:
        "Our AI breaks down every piece — jacket, sneakers, bag, watch, even the sunglasses. Identified in seconds. Not \"similar vibes.\" The actual piece. With match confidence scores.",
      color: "from-peach to-amber",
      bgLight: "bg-amber/5",
      iconBg: "bg-amber/10 text-amber",
    },
    {
      num: "03",
      icon: <ShoppingBag className="w-7 h-7" />,
      title: "Shop",
      subtitle: "Compare & Buy",
      description:
        "See every option side by side. Compare prices across dozens of stores. Find the exact match or get a lookalike at your budget. One tap to buy. Cashback built in.",
      color: "from-amber to-emerald-400",
      bgLight: "bg-emerald-50",
      iconBg: "bg-emerald-500/10 text-emerald-500",
    },
  ];

  return (
    <AnimatedSection className="py-20 sm:py-28 bg-white" delay={0.1}>
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        <div className="text-center mb-16">
          <motion.p
            variants={fadeUp}
            className="text-coral font-semibold text-sm uppercase tracking-widest mb-4"
          >
            Effortlessly simple
          </motion.p>
          <motion.h2
            variants={fadeUp}
            custom={1}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4"
            style={{ fontFamily: "var(--font-playfair), Georgia, serif" }}
          >
            Three taps. That&apos;s it.
          </motion.h2>
          <motion.p
            variants={fadeUp}
            custom={2}
            className="text-text-secondary text-lg max-w-xl mx-auto"
          >
            From \"I love that outfit\" to \"it&apos;s on its way to my door\" — in under 30 seconds.
          </motion.p>
        </div>

        <motion.div
          variants={stagger}
          className="grid md:grid-cols-3 gap-8 relative"
        >
          {/* Connecting line */}
          <div className="hidden md:block absolute top-24 left-[20%] right-[20%] h-0.5 bg-gradient-to-r from-coral/20 via-amber/20 to-emerald-400/20" />

          {steps.map((step, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              custom={i + 1}
              className="relative text-center group"
            >
              {/* Step number */}
              <div className="relative inline-flex mb-6">
                <div
                  className={`w-20 h-20 rounded-2xl ${step.iconBg} flex items-center justify-center mx-auto transition-transform duration-300 group-hover:scale-110`}
                >
                  {step.icon}
                </div>
                <div className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-white shadow-md flex items-center justify-center">
                  <span
                    className="text-xs font-bold"
                    style={{
                      background: `linear-gradient(135deg, #E8505B, #F59E0B)`,
                      WebkitBackgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                    }}
                  >
                    {step.num}
                  </span>
                </div>
              </div>

              <h3
                className="text-2xl font-bold mb-1"
                style={{ fontFamily: "var(--font-playfair), Georgia, serif" }}
              >
                {step.title}
              </h3>
              <p className="text-coral font-medium text-sm mb-3">
                {step.subtitle}
              </p>
              <p className="text-text-secondary text-sm leading-relaxed max-w-xs mx-auto">
                {step.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </AnimatedSection>
  );
}

/* ═══════════════════════════════════════════
   FEATURES SHOWCASE
   ═══════════════════════════════════════════ */
function FeaturesSection() {
  const features = [
    {
      icon: <Sparkles className="w-6 h-6" />,
      title: "AI That Actually Gets Fashion",
      desc: "Not just image recognition. Our AI understands style — color theory, silhouettes, occasion matching. It tells you WHY an outfit works, not just what it is.",
      color: "bg-coral/10 text-coral",
      highlight: "Learn style, don't just copy it.",
    },
    {
      icon: <BadgeDollarSign className="w-6 h-6" />,
      title: "Budget? We Got You.",
      desc: "Can't afford the exact piece? SpotStyle finds lookalikes at 3 price tiers — luxury, mid-range, and budget. Look like a million bucks on any budget.",
      color: "bg-emerald-500/10 text-emerald-500",
      highlight: "Same look. Your price.",
    },
    {
      icon: <Palette className="w-6 h-6" />,
      title: "Your Style DNA",
      desc: "Set your body type, preferences, and budget once. Every result is personalized to actually look good on YOU — not just some random model.",
      color: "bg-violet-500/10 text-violet-500",
      highlight: "Personalized to your body & taste.",
    },
    {
      icon: <Link2 className="w-6 h-6" />,
      title: "Share the Look",
      desc: "Spotted something fire? One link shares the entire outfit breakdown. Your friends can shop it instantly. Fashion goes viral — literally.",
      color: "bg-amber/10 text-amber",
      highlight: "One link. Full outfit. Shop it.",
    },
    {
      icon: <BookmarkPlus className="w-6 h-6" />,
      title: "Your Spotted Feed",
      desc: "Every outfit you spot, saved into a personal mood board. Organise by occasion, season, or vibe. Think Pinterest — but for real outfits you actually saw.",
      color: "bg-pink-500/10 text-pink-500",
      highlight: "Pinterest meets real life.",
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Import From Anywhere",
      desc: "Screenshot from TikTok, Instagram, Netflix — drag it into SpotStyle and it just works. No app switching. No context lost. Pure fashion discovery.",
      color: "bg-orange-500/10 text-orange-500",
      highlight: "Works everywhere you see style.",
    },
  ];

  return (
    <AnimatedSection
      className="py-20 sm:py-28 bg-warm-gray bg-mesh"
      delay={0.1}
    >
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        <div className="text-center mb-16">
          <motion.p
            variants={fadeUp}
            className="text-coral font-semibold text-sm uppercase tracking-widest mb-4"
          >
            Not just another search tool
          </motion.p>
          <motion.h2
            variants={fadeUp}
            custom={1}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4"
            style={{ fontFamily: "var(--font-playfair), Georgia, serif" }}
          >
            Built different.{" "}
            <span className="text-gradient">On purpose.</span>
          </motion.h2>
          <motion.p
            variants={fadeUp}
            custom={2}
            className="text-text-secondary text-lg max-w-2xl mx-auto"
          >
            Every other app gives you a search bar. SpotStyle gives you a fashion
            companion that understands what you actually want.
          </motion.p>
        </div>

        <motion.div
          variants={stagger}
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {features.map((f, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              custom={i + 1}
              className="group bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-default border border-transparent hover:border-coral/10"
            >
              <div
                className={`w-12 h-12 rounded-xl ${f.color} flex items-center justify-center mb-4 transition-transform duration-300 group-hover:scale-110`}
              >
                {f.icon}
              </div>
              <h3 className="text-lg font-bold text-charcoal mb-2">{f.title}</h3>
              <p className="text-text-secondary text-sm leading-relaxed mb-3">
                {f.desc}
              </p>
              <div
                className="inline-flex items-center gap-1.5 text-coral text-sm font-semibold"
              >
                {f.highlight}
                <ChevronRight className="w-3.5 h-3.5" />
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </AnimatedSection>
  );
}

/* ═══════════════════════════════════════════
   COMPARISON TABLE — WHY US
   ═══════════════════════════════════════════ */
function ComparisonSection() {
  const rows = [
    { feature: "Identifies individual pieces", g: true, s: true, st: true, ss: true },
    { feature: "Budget alternatives at 3 price points", g: false, s: false, st: false, ss: true },
    { feature: "Explains WHY an outfit works", g: false, s: false, st: false, ss: true },
    { feature: "Personal style profile filtering", g: false, s: false, st: false, ss: true },
    { feature: "Shareable outfit links", g: false, s: false, st: false, ss: true },
    { feature: "Works with screenshots & social media", g: false, s: true, st: false, ss: true },
    { feature: "Cashback built into every purchase", g: false, s: false, st: true, ss: true },
    { feature: "Personal mood board / spotted feed", g: false, s: false, st: false, ss: true },
  ];

  return (
    <AnimatedSection className="py-20 sm:py-28 bg-white" delay={0.1}>
      <div className="max-w-4xl mx-auto px-6 sm:px-8">
        <div className="text-center mb-12">
          <motion.p
            variants={fadeUp}
            className="text-coral font-semibold text-sm uppercase tracking-widest mb-4"
          >
            The honest comparison
          </motion.p>
          <motion.h2
            variants={fadeUp}
            custom={1}
            className="text-3xl sm:text-4xl font-bold mb-4"
            style={{ fontFamily: "var(--font-playfair), Georgia, serif" }}
          >
            Others search.{" "}
            <span className="text-gradient">SpotStyle understands.</span>
          </motion.h2>
        </div>

        <motion.div variants={fadeUp} custom={2} className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead>
              <tr className="border-b-2 border-border">
                <th className="text-left py-4 px-4 font-medium text-text-muted text-xs uppercase tracking-wider">
                  Feature
                </th>
                <th className="text-center py-4 px-3 font-medium text-text-muted text-xs uppercase tracking-wider">
                  Google Lens
                </th>
                <th className="text-center py-4 px-3 font-medium text-text-muted text-xs uppercase tracking-wider">
                  Screenshop
                </th>
                <th className="text-center py-4 px-3 font-medium text-text-muted text-xs uppercase tracking-wider">
                  Shop the Look
                </th>
                <th
                  className="text-center py-4 px-3 font-semibold text-xs uppercase tracking-wider rounded-t-xl"
                  style={{
                    background:
                      "linear-gradient(135deg, rgba(232,80,91,0.08), rgba(245,158,11,0.08))",
                    color: "var(--coral)",
                  }}
                >
                  SpotStyle ✦
                </th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr
                  key={i}
                  className="border-b border-border/50 hover:bg-warm-gray/50 transition-colors"
                >
                  <td className="py-3.5 px-4 text-charcoal font-medium">
                    {row.feature}
                  </td>
                  <td className="py-3.5 px-3 text-center">
                    <CellCheck value={row.g} />
                  </td>
                  <td className="py-3.5 px-3 text-center">
                    <CellCheck value={row.s} />
                  </td>
                  <td className="py-3.5 px-3 text-center">
                    <CellCheck value={row.st} />
                  </td>
                  <td
                    className="py-3.5 px-3 text-center"
                    style={{
                      background:
                        "linear-gradient(135deg, rgba(232,80,91,0.04), rgba(245,158,11,0.04))",
                    }}
                  >
                    <CellCheck value={row.ss} highlight />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      </div>
    </AnimatedSection>
  );
}

function CellCheck({ value, highlight = false }: { value: boolean; highlight?: boolean }) {
  if (value) {
    return (
      <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-50">
        <Check className={`w-3.5 h-3.5 ${highlight ? "text-emerald-600" : "text-emerald-500"}`} />
      </div>
    );
  }
  return (
    <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-gray-50">
      <X className="w-3.5 h-3.5 text-gray-300" />
    </div>
  );
}

/* ═══════════════════════════════════════════
   TESTIMONIALS
   ═══════════════════════════════════════════ */
function TestimonialsSection() {
  const testimonials = [
    {
      name: "Sarah M.",
      handle: "@sarahstyle",
      avatar: "S",
      avatarBg: "bg-coral",
      rating: 5,
      text: "I spotted a girl on the subway wearing the most perfect trench coat. Opened SpotStyle, snapped it, and 10 seconds later I owned it. This app is genuinely dangerous for my wallet.",
      verified: true,
    },
    {
      name: "James K.",
      handle: "@jameskfits",
      avatar: "J",
      avatarBg: "bg-amber",
      rating: 5,
      text: "I used to screenshot outfits from TikTok and spend hours searching. Now it's literally one tap. I've completely rebuilt my wardrobe in 3 weeks. My friends think I hired a stylist.",
      verified: true,
    },
    {
      name: "Priya R.",
      handle: "@priyaspotted",
      avatar: "P",
      avatarBg: "bg-violet-500",
      rating: 5,
      text: "The style rating feature is chef's kiss. It actually taught me WHY certain outfits work — colour theory, silhouette balance. My fashion IQ went from zero to actually knowing what I'm doing.",
      verified: true,
    },
  ];

  return (
    <AnimatedSection
      className="py-20 sm:py-28 bg-warm-gray bg-mesh"
      delay={0.1}
    >
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        <div className="text-center mb-14">
          <motion.p
            variants={fadeUp}
            className="text-coral font-semibold text-sm uppercase tracking-widest mb-4"
          >
            Real people. Real obsession.
          </motion.p>
          <motion.h2
            variants={fadeUp}
            custom={1}
            className="text-3xl sm:text-4xl font-bold"
            style={{ fontFamily: "var(--font-playfair), Georgia, serif" }}
          >
            Don&apos;t take our word for it.
          </motion.h2>
        </div>

        <motion.div
          variants={stagger}
          className="grid md:grid-cols-3 gap-6"
        >
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              custom={i + 1}
              className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <StarRating count={t.rating} />
              <p className="mt-4 mb-6 text-text-secondary text-sm leading-relaxed italic">
                &ldquo;{t.text}&rdquo;
              </p>
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-full ${t.avatarBg} flex items-center justify-center text-white font-bold text-sm`}
                >
                  {t.avatar}
                </div>
                <div>
                  <div className="font-semibold text-charcoal text-sm flex items-center gap-1.5">
                    {t.name}
                    {t.verified && (
                      <span className="inline-flex items-center gap-0.5 text-[10px] text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-full font-medium">
                        <Shield className="w-2.5 h-2.5" />
                        Verified
                      </span>
                    )}
                  </div>
                  <div className="text-text-muted text-xs">{t.handle}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </AnimatedSection>
  );
}

/* ═══════════════════════════════════════════
   STATS BAR
   ═══════════════════════════════════════════ */
function StatsSection() {
  const stats = [
    { value: "50K+", label: "Happy Spotters", icon: <Users className="w-5 h-5" /> },
    { value: "2M+", label: "Outfits Identified", icon: <Eye className="w-5 h-5" /> },
    { value: "4.9★", label: "App Store Rating", icon: <Star className="w-5 h-5" /> },
    { value: "<10s", label: "Average Spot Time", icon: <Zap className="w-5 h-5" /> },
  ];

  return (
    <AnimatedSection className="py-16 bg-white" delay={0.1}>
      <div className="max-w-5xl mx-auto px-6 sm:px-8">
        <motion.div
          variants={stagger}
          className="grid grid-cols-2 md:grid-cols-4 gap-8"
        >
          {stats.map((s, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              custom={i + 1}
              className="text-center"
            >
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-coral/5 text-coral mb-3">
                {s.icon}
              </div>
              <div
                className="text-3xl sm:text-4xl font-bold text-gradient mb-1"
                style={{ fontFamily: "var(--font-playfair), Georgia, serif" }}
              >
                {s.value}
              </div>
              <div className="text-text-muted text-sm font-medium">{s.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </AnimatedSection>
  );
}

/* ═══════════════════════════════════════════
   FINAL CTA
   ═══════════════════════════════════════════ */
function FinalCTA() {
  return (
    <AnimatedSection className="py-20 sm:py-28 relative overflow-hidden" delay={0.1}>
      {/* Gradient background */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(135deg, #E8505B 0%, #FF8A6B 35%, #F59E0B 70%, #FBBF24 100%)",
        }}
      />
      {/* Pattern overlay */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, white 1px, transparent 0)`,
          backgroundSize: "40px 40px",
        }}
      />
      {/* Glow effects */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-72 h-72 bg-white/10 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-3xl mx-auto px-6 sm:px-8 text-center">
        <motion.div variants={fadeUp}>
          <Heart className="w-10 h-10 text-white/80 mx-auto mb-6" />
        </motion.div>

        <motion.h2
          variants={fadeUp}
          custom={1}
          className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4 leading-tight"
          style={{ fontFamily: "var(--font-playfair), Georgia, serif" }}
        >
          Your next favourite outfit is out there right now.
        </motion.h2>

        <motion.p
          variants={fadeUp}
          custom={2}
          className="text-white/85 text-lg sm:text-xl mb-3 leading-relaxed"
        >
          Someone is wearing it on a street. In a cafe. On your feed.
        </motion.p>

        <motion.p
          variants={fadeUp}
          custom={3}
          className="text-white/70 text-base mb-10 font-medium"
        >
          Don&apos;t let it get away.
        </motion.p>

        <motion.div
          variants={fadeUp}
          custom={4}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <button className="group relative overflow-hidden px-10 py-5 rounded-2xl bg-white text-charcoal font-bold text-lg shadow-2xl hover:shadow-3xl transition-shadow duration-300 cursor-pointer focus:outline-none focus:ring-4 focus:ring-white/50">
              <span className="relative z-10 flex items-center gap-2.5">
                <Download className="w-5 h-5" />
                Download SpotStyle Free
                <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
              </span>
            </button>
          </motion.div>

          <div className="flex items-center gap-4 text-white/80 text-sm">
            <div className="flex items-center gap-1.5">
              <Smartphone className="w-4 h-4" />
              iOS & Android
            </div>
            <div className="w-1 h-1 rounded-full bg-white/40" />
            <div className="flex items-center gap-1.5">
              <Shield className="w-4 h-4" />
              Free forever plan
            </div>
          </div>
        </motion.div>

        {/* App store badges visual */}
        <motion.div
          variants={fadeIn}
          className="flex items-center justify-center gap-4 mt-8"
        >
          <div className="bg-black/20 backdrop-blur-sm rounded-xl px-5 py-3 flex items-center gap-2.5">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 text-white">
              <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
            </svg>
            <div className="text-left">
              <div className="text-white/60 text-[10px] leading-tight">
                Download on the
              </div>
              <div className="text-white font-semibold text-sm leading-tight">
                App Store
              </div>
            </div>
          </div>
          <div className="bg-black/20 backdrop-blur-sm rounded-xl px-5 py-3 flex items-center gap-2.5">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 text-white">
              <path d="M3.609 1.814L13.792 12 3.61 22.186a.996.996 0 01-.61-.92V2.734a1 1 0 01.609-.92zm10.89 10.893l2.302 2.302-10.937 6.333 8.635-8.635zm3.199-3.199l2.807 1.626a1 1 0 010 1.732l-2.807 1.626L15.206 12l2.492-2.492zM5.864 2.658L16.802 8.99l-2.303 2.303-8.635-8.635z" />
            </svg>
            <div className="text-left">
              <div className="text-white/60 text-[10px] leading-tight">
                GET IT ON
              </div>
              <div className="text-white font-semibold text-sm leading-tight">
                Google Play
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatedSection>
  );
}

/* ═══════════════════════════════════════════
   FOOTER
   ═══════════════════════════════════════════ */
function Footer() {
  return (
    <footer className="bg-charcoal text-white/60 py-12">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <span
              className="text-2xl font-bold"
              style={{ fontFamily: "var(--font-playfair), Georgia, serif" }}
            >
              Spot
              <span className="text-coral">Style</span>
            </span>
          </div>

          <div className="flex items-center gap-6 text-sm">
            <a href="#" className="hover:text-white transition-colors">
              Privacy
            </a>
            <a href="#" className="hover:text-white transition-colors">
              Terms
            </a>
            <a href="#" className="hover:text-white transition-colors">
              Support
            </a>
            <a href="#" className="hover:text-white transition-colors">
              Press
            </a>
          </div>

          <div className="text-xs text-white/30">
            &copy; 2025 SpotStyle. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ═══════════════════════════════════════════
   STICKY MOBILE CTA BAR
   ═══════════════════════════════════════════ */
function StickyMobileCTA() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 lg:hidden bg-white/90 backdrop-blur-lg border-t border-border px-4 py-3 safe-area-pb">
      <motion.button
        whileTap={{ scale: 0.97 }}
        className="w-full py-3.5 rounded-xl text-white font-semibold text-base shadow-lg cursor-pointer focus:outline-none"
        style={{
          background:
            "linear-gradient(135deg, #E8505B 0%, #FF8A6B 50%, #F59E0B 100%)",
        }}
      >
        <span className="flex items-center justify-center gap-2">
          <Download className="w-4 h-4" />
          Download SpotStyle — It&apos;s Free
        </span>
      </motion.button>
    </div>
  );
}

/* ═══════════════════════════════════════════
   MAIN PAGE
   ═══════════════════════════════════════════ */
export default function Home() {
  return (
    <main className="min-h-screen flex flex-col bg-cream">
      <HeroSection />
      <TrustBar />
      <ProblemSection />
      <HowItWorks />
      <FeaturesSection />
      <ComparisonSection />
      <StatsSection />
      <TestimonialsSection />
      <FinalCTA />
      <Footer />
      <StickyMobileCTA />
    </main>
  );
}