import type { Metadata } from "next";
import { DM_Sans, Playfair_Display } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const dmSans = DM_Sans({
  variable: "--font-dm-sans",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
});

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
});

export const metadata: Metadata = {
  title: "SpotStyle — See It. Love It. Own It.",
  description:
    "Snap any outfit. AI finds every piece in seconds. Shop the exact match or find it at your budget. The fashion companion that actually gets you.",
  keywords: [
    "SpotStyle",
    "fashion app",
    "outfit identification",
    "AI fashion",
    "shop the look",
    "style companion",
  ],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "SpotStyle — See It. Love It. Own It.",
    description:
      "Snap any outfit. AI finds every piece in seconds. Shop instantly.",
    siteName: "SpotStyle",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "SpotStyle — See It. Love It. Own It.",
    description:
      "Snap any outfit. AI finds every piece in seconds. Shop instantly.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${dmSans.variable} ${playfair.variable} antialiased`}
        style={{ fontFamily: "var(--font-dm-sans), system-ui, sans-serif" }}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}